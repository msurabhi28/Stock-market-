import React from 'react';
import StockView from "./StockView/StockView";

const Markets = () => {
  return (
    <>
    <StockView/>
    </>
  );
}

export default Markets;
